import logo from './logo.svg';
import './App.css';
import React from 'react'
import ReactDOM from 'react-dom'
import Menu from './component/Menu';
import { BrowserRouter, Route} from 'react-router-dom';
import { Container } from 'reactstrap';



function App() {
  return (
   <BrowserRouter>
   <Container>
  <div className="App">
    <h1>Welcome</h1>
  <Route path="/" component={Menu} />
   
   </div>
   </Container>
   </BrowserRouter>
        
  );
}

export default App;
