import React from "react";
import mystore from "./store";
import Login from './Login'
import CustomerRegister from "./CustomerRegister";
import TruckOwnerRegister from "./TruckOwnerRegister";
import { BrowserRouter,Route,Link} from "react-router-dom";
import TruckOwnerHome from './TRuckOwnerHome'
import CustomerHome from './CustomerHome'
import Home from'./Home'
import { ListGroup } from "reactstrap";

export default class Menu extends React.Component{
constructor(props)
{
  super(props);
      this.state={

        flag:false
    }
  
}

render()
    
  {  mystore.subscribe(()=>{this.setState({flag:mystore.getState().loggedin})})
  return(
    
  
    <BrowserRouter>
    
    <div style={{display:this.state.flag?'none':'block'}}>
    

    <ListGroup>
     <Link className="list-group-item list-group-item-action" tag="a" to="/login" action>Login</Link> <br/>
     <Link className="list-group-item list-group-item-action" tag="a" to="/cregister" action>Customer Register</Link> <br/>
     <Link className="list-group-item list-group-item-action" tag="a" to="/tregister" action>Truck Owner Register</Link>  <br/>
                     
    </ListGroup>
         
    
    
   <div>
       <Route path="/login" component={Login} />
     <Route path="/cregister" component={CustomerRegister} />  
     <Route path="/tregister" component={TruckOwnerRegister} />
    
</div>
</div>
<    Route path="/truckownerhome"component={TruckOwnerHome }/>
     <Route path="/customerhome"component={CustomerHome}/>
   </BrowserRouter>
   
   
        
  );
}



}


