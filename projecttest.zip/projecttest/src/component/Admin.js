import React from "react";

class Admin extends React.Component{
constructor(props)
{
    super(props);
}

    render(){
   return(
<div>
    <h1>Admin Home Page</h1>
    <a href="#">View Orders</a>

</div>


   );


    }



}

export default Admin;