import React from "react";
import mystore from "./store";
class Order extends React.Component {

    constructor(props)
    {
   super(props);
    this.state={
          driver_name:"",
          driver_contact:"",
          booking:{}
    }  
     
  }

  handleChange=(e)=>{
const nm=e.target.name;
const val=e.target.value;
this.setState({[nm] :val});

  }

  
submitInfo=(event)=>{
  event.preventDefault();
  alert("called");
const requestOptions={
method:'POST',
headers : {

  'Content-Type' :'application/JSON'
},
body : JSON.stringify({
    source_add:this.state.source_add,
    dest_add:this.state.dest_add,
    m_weight:this.state.m_weight,
    m_qty:this.state.m_qty,
    m_price:this.state.m_price,
    freight_date:this.state.freight_date
    
})
};
fetch("http://localhost:8080/order",requestOptions)
.then(res=> res.json())
.then(data=>this.setState({order:data}))
}

 
render()
{
return(
   <div>
<h1> Enter Order details</h1>
  <form>
   Enter Source Address: <input type="text" name="source_add" onChange={this.handleChange}/><br/>
    Enter Destination Address : <input type="pwd" name="dest_add" onChange={this.handleChange}/><br/>
    Enter Material Weight : <input type="date" name="m_weight" onChange={this.handleChange}/><br/>
    Enter Material Quantity: <input type="text" name="m_qty" onChange={this.handleChange}/><br/>
    Enter Material Price : <input type="text" name="m_price" onChange={this.handleChange}/><br/>
    Enter Freight Date : <input type="date"name="freight_date" onChange={this.handleChange}/><br/>
    
    <input type="submit" onClick={this.submitInfo} value="Create an Order"/>
   </form>
   <br/>
   <p>{this.state.order.order_id } is inserted</p>



   </div>





);

}

}
export default Order;