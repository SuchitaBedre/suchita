package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.TruckOwner;
import com.example.demo.repositories.TruckOwnerRepository;

@Service
public class TruckOwnerService 

{
	@Autowired
	TruckOwnerRepository trepo;
	
	public TruckOwner add(TruckOwner t)
	{
		
		return trepo.save(t);
	}

	
	
}
