package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Customer;
import com.example.demo.entities.Login;
import com.example.demo.entities.TruckOwner;
import com.example.demo.repositories.CustomerRepository;
import com.example.demo.repositories.LoginRepository;
import com.example.demo.repositories.TruckOwnerRepository;

@Service
public class LoginService {
	
	@Autowired
	LoginRepository lrepo;

	@Autowired
	CustomerRepository crepo;
	
	@Autowired
	TruckOwnerRepository trepo;
	
	
public Login add(Login l)
	{
	return lrepo.save(l);	
		
	}
	
	/*public String checklogin(String uid,String pwd)
	{
		
		return lrepo.checklogin(uid,pwd);
	}*/

	
	public Object checkLogin(String uid,String pwd)
	{
		
		System.out.println(uid+":"+pwd);
		TruckOwner t=null;
		List<Object []> l=lrepo.checkLogin(uid, pwd);
		
		System.out.println(l.get(0)[0]+":"+l.get(0)[1]+":"+l.get(0)[2]+":"+l.get(0)[3]);
		if(l.size()==1)
		{
			Customer c=null;
			if(l.get(0)[0].equals("customer"))
			{
				
				Optional<Customer> cp=crepo.findById((int)l.get(0)[3]);
				try
				{
					c=cp.get();
				}
				catch(Exception e)
				{
					c=null;
				}
				
			}
			
			return c;
		}
		
		
			else if(l.get(0)[0].equals("truckowner"))
			{
				
			Optional<TruckOwner> tp=trepo.findById((String)l.get(0)[3]);
				try
				{
					t=tp.get();
				}
				catch(Exception e)
				{
					t=null;
				}
				
			}
			
		return t;
		}
	

	
}
