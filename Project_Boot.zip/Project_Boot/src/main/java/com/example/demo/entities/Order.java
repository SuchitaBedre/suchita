package com.example.demo.entities;

import javax.persistence.*;

@Entity
@Table(name="order_table")
public class Order {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int order_id;
	
	@Column
	String source_add;
	
	@Column
	
	String dest_add;
	@Column
	String m_weight;
	
	@Column
	String m_qty;
	
	@Column
	
	String m_price;
	
	@ManyToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
	@JoinColumn(name="cust_id")
	private Customer cust;

	
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Order(String source_add, String dest_add, String m_weight, String m_qty, String m_price, Customer cust) {
		super();
		this.source_add = source_add;
		this.dest_add = dest_add;
		this.m_weight = m_weight;
		this.m_qty = m_qty;
		this.m_price = m_price;
		this.cust = cust;
	}


	public int getOrder_id() {
		return order_id;
	}


	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}


	public String getSource_add() {
		return source_add;
	}


	public void setSource_add(String source_add) {
		this.source_add = source_add;
	}


	public String getDest_add() {
		return dest_add;
	}


	public void setDest_add(String dest_add) {
		this.dest_add = dest_add;
	}


	public String getM_weight() {
		return m_weight;
	}


	public void setM_weight(String m_weight) {
		this.m_weight = m_weight;
	}


	public String getM_qty() {
		return m_qty;
	}


	public void setM_qty(String m_qty) {
		this.m_qty = m_qty;
	}


	public String getM_price() {
		return m_price;
	}


	public void setM_price(String m_price) {
		this.m_price = m_price;
	}


	public Customer getCust() {
		return cust;
	}


	public void setCust(Customer cust) {
		this.cust = cust;
	}


	@Override
	public String toString() {
		return "Order [order_id=" + order_id + ", source_add=" + source_add + ", dest_add=" + dest_add + ", m_weight="
				+ m_weight + ", m_qty=" + m_qty + ", m_price=" + m_price + ", cust=" + cust + "]";
	}

	
	

}
