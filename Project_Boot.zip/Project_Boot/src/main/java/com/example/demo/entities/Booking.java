package com.example.demo.entities;

import java.sql.Date;

import javax.persistence.*;

@Entity
@Table(name="booking")
public class Booking {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int booking_id;
	
	//@OneToOne (fetch = FetchType.EAGER)
	@Column
	String driver_name;
	
	//@OneToOne (fetch = FetchType.EAGER)
	@Column
	String driver_contact;
	
		
	@OneToOne (fetch = FetchType.EAGER)
	@JoinColumn(name="truck_no")
	TruckOwner truck_no;
	
	@OneToOne (fetch = FetchType.EAGER)
	@JoinColumn(name="order_id")
	Order order_id;
	
	

	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Booking(String driver_name, String driver_contact, TruckOwner truck_no, Order order_id) {
		super();
		this.driver_name = driver_name;
		this.driver_contact = driver_contact;
		this.truck_no = truck_no;
		this.order_id = order_id;
	}



	public int getBooking_id() {
		return booking_id;
	}



	public void setBooking_id(int booking_id) {
		this.booking_id = booking_id;
	}



	public String getDriver_name() {
		return driver_name;
	}



	public void setDriver_name(String driver_name) {
		this.driver_name = driver_name;
	}



	public String getDriver_contact() {
		return driver_contact;
	}



	public void setDriver_contact(String driver_contact) {
		this.driver_contact = driver_contact;
	}



	public TruckOwner getTruck_no() {
		return truck_no;
	}



	public void setTruck_no(TruckOwner truck_no) {
		this.truck_no = truck_no;
	}



	public Order getOrder_id() {
		return order_id;
	}



	public void setOrder_id(Order order_id) {
		this.order_id = order_id;
	}



	@Override
	public String toString() {
		return "Booking [booking_id=" + booking_id + ", driver_name=" + driver_name + ", driver_contact="
				+ driver_contact + ", truck_no=" + truck_no + ", order_id=" + order_id + "]";
	}








}
